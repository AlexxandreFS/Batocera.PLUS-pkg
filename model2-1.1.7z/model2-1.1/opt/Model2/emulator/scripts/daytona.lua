require("model2")
function Init()
end
function Frame()
local gameState = I960_ReadByte(0x5010A4)
if   gameState==0x16
or gameState==0x03
or gameState==0x04
or gameState==0x05
or gameState==0x06
or gameState==0x07
then 
Model2_SetStretchBLow(1)
Model2_SetWideScreen(1)
else
Model2_SetStretchBLow(0)
Model2_SetWideScreen(0)
end 
end
